# Books API

This is a simple Express.js project for managing a list of books using in-memory storage.

## Features

- Get all books
- Add a new book
- Update a book by ID
- Delete a book by ID

## How to Run

1. Install dependencies:
   ```bash
   npm install
   ```

2. Start the server:
   ```bash
   node index.js
   ```

Server will run at: `http://localhost:3000`